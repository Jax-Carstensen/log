const PORT = 8787;

var socket;
var connected = false;

var receivedPing = true;
var ping = 0;
var lastPing = new Date();

let itemLog = [];

var audio;
function socketManager() {
    if (!socket || !connected) return;
    socket.on("pingReturn", function () {
        ping = new Date() - lastPing;
        receivedPing = true;
    });
    socket.on("disconnect", function () {
        console.log("Disconnected from server");
    });
    socket.on("location", function (s) {
        structures = s.structures;
        blocks = s.blocks;
    });
    socket.on('state', function (Players) {
        players = Players;
    });
    socket.on("receive blueprints", function (allBlueprints) {
        blueprints = allBlueprints;
    });
    socket.emit("send logs");
    socket.on("logs", function(newItemLog){
        itemLog = newItemLog;
        showLog();
    });
    setInterval(function () {
        if (receivedPing) {
            receivedPing = false;
            socket.emit("pingTest");
            lastPing = new Date();
        }
        document.getElementById("ping").innerHTML = "PING: " + ping + "ms";
    }, 1000);
}

function showLog(){
    console.log(itemLog.length);
    let classes = [
        "storeN",
        "storeC",
        "date",
        "quantity",
        "description",
        "newOtn",
        "partNumber",
        "reason",
        "sentBy",
        "returnedDate",
        "done"
    ];
    let names = [
        "Store Number",
        "Store Contact",
        "Send Date",
        "Quantity",
        "Description",
        "NewOTN",
        "Part Number",
        "Reason",
        "Sent By",
        "Returned Date",
        "Done"
    ];
    string = "<tr class='large'><td class='storeN'>Store #</td><td class='storeC'>Store Contact</td><td class='date'>Date</td><td class='quantity'>Quantity</td><td class='description'>Description</td><td class='newOtn'>New/Otn?</td><td class='partNumber'>Part Number</td><td class='reason'>Reason for replacement/symptoms</td><td class='sentBy'>Sent By</td><td class='returnedDate'>Returned Date</td><td class='done'>Done</td></tr>";
    for(let x = 0; x < itemLog.length; x++){
        string += "<tr>";
        for(let y = 0; y < names.length; y++){
            string += "<td class='" + classes[y] + "'>"
            if(itemLog[x][names[y]] == ""){
                if(names[y] == "Done"){
                    string += "<div onclick='done(" + itemLog[x]["ID"] + ");' class='button doneButton'>Mark Done</div>";
                }else if(names[y] == "Returned Date"){
                    string += "<div onclick='returnItem(" + itemLog[x]["ID"] + ");' class='button returnButton'>Return Today</div>";
                }
            }else{
                string += itemLog[x][names[y]]
            }
            string += "</td>";
        }
        string += "</tr>";
    }
    document.getElementById("log").innerHTML = string;
}

function getCurrentDate(){
    rn = new Date();
    month = (rn.getMonth() + 1).toString();
    day = rn.getDate().toString();
    year = rn.getFullYear().toString();
    if(month.length <= 1) 
        month = "0" + month;
    if(day.length <= 1)
        day = "0" + day;
    
    return month + "/" + day + "/" + year;
}

function gotoAddLog(){
    
}

function returnItem(itemId){
    socket.emit("returnItem", itemId, getCurrentDate());
}
function done(itemId){
    socket.emit("done", itemId);
}

function login() {
    if(!socket) socket = io.connect("localhost:" + PORT, function(){
        console.log("OH YEAH");
    });
    socket.emit('new user');
    socket.on("connected", function () {
        connected = true;
        socketManager();
    });
    socket.on("disconnected", function () {
        socket = null;
        console.log("You have been disconnected");
    });
    socket.on("wrong password", function () {
        document.getElementById("error").innerHTML = "Wrong password, or that account already exists!";
    });
}
login();