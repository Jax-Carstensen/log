var express = require('express');
var http = require('http');
var path = require('path');
var socketIO = require('socket.io');
const fs = require('fs');

const fileLocation = path.join(__dirname, "/files");
const logFile = path.join(fileLocation, 'log.json');
const port = 8787;

var app = express();
var server = http.Server(app);
var io = socketIO(server);

app.use(express.static('public'));

//Serves all the request which includes /images in the url from Images folder
app.use('/images', express.static(__dirname + '/Images'));

app.set('port', port);
app.use('/static', express.static(__dirname + '/static'));

// Routing
app.get('/', function(request, response) {
  response.sendFile(path.join(__dirname, 'static/testing.html'));
});

// Starts the server.
server.listen(port, function() {
  console.log('Starting server on port ' + port.toString());
});

let sockets = [];
let itemLog = [];

function saveItemLog(){
    items = { "items": itemLog };
    fs.writeFile(logFile, JSON.stringify(items), function (err) {
        if (err) {
            console.log("Error: " + err.toString());
        }
    });
}

function pathExists(path) {
    try {
        if (fs.existsSync(path)) {
            return true;
        }
    } catch (err) {
        return false;
    }
    return false;
}

function createFile(path, add) {
    var add = add || "";
    if (path.includes(".json") && add == "" && !path.includes("world.json")) {
        add = "{}";
    }
    fs.appendFile(path, add, function (err) {
        if (err) throw err;
    }); 
}

function start() {
    console.log("Server starting up...");
    //If the folder that files are stored in doesn't exist, create it
    if (!pathExists(fileLocation)) {
        fs.mkdirSync(fileLocation);
        console.log("File folder has been initialized");
    }
    //If the log file doesn't exist, create it. If it does exist, open it and read the file
    if (!pathExists(logFile)) {
        createFile(logFile, "{\"items\": []}");
    }else{
        fs.readFile(logFile, 'utf8', function(err, content){
            if(err){
                console.log(err);
            }else{
                //console.log(JSON.parse(content));
                itemLog = JSON.parse(content)["items"];
                console.log(itemLog.length + " log items have been loaded successfully.");
            }
        });
    }
    //addLog("841-1", "MGR", "10/31", "1", "27in Monitor", "New", "", "blue screens", "KB", "", "");
}

function printCurrentUsers(){
    console.log("There are currently " + (sockets.length).toString() + " users connected");
}

function addLog(storeN, storeC, sendDate, qty, description, NOTN, partNum, reason, sentBy, returnedDate, done){
    itemLog.push({
        "Store Number": storeN,
        "Store Contact": storeC,
        "Send Date": sendDate,
        "Quantity": qty,
        "Description": description,
        "NewOTN": NOTN,
        "Part Number": partNum,
        "Reason": reason,
        "Sent By": sentBy,
        "Returned Date": returnedDate,
        "Done": done,
        "ID": itemLog.length
    });
    saveItemLog();
}

function sendLogs(socket){
    socket.emit("logs", itemLog);
}
function sendLogsToAll(){
    for(let x = 0; x < sockets.length; x++){
        sendLogs(sockets[x]);
    }
}

//Called when a new client connects
io.on('connection', function (socket) {
    //When the client is first added
    socket.on('new user', function () {
        sockets.push(socket);
        socket.emit("connected");
        printCurrentUsers();
    });
    //When the client disconnects
    socket.on('disconnect', function () {
        //Remove user from out list of sockets
        if (sockets.includes(socket)) {
            sockets.splice(sockets.indexOf(socket), 1);
        }
        printCurrentUsers();
    });
    //Used to measure ping
    socket.on("pingTest", function () {
        socket.emit("pingReturn");
    });
    socket.on("done", function(itemId){
        itemLog[Number(itemId)]["Done"] = "X";
        saveItemLog();
        sendLogsToAll();
    });
    socket.on("returnItem", function(itemId, returnDate){
        itemLog[Number(itemId)]["Returned Date"] = returnDate;
        saveItemLog();
        sendLogsToAll();
    });
    socket.on("message", function (message) {
        if (message[0] == "/") {
            var message = message.split("/")[1];
            if (message == "wipe") {
                while (sockets.length > 0) {
                    sockets[0].disconnect();
                    sockets.splice(0, 1);
                }
                fs.unlinkSync(worldFile, function (err) {
                    if (err) console.log(err);
                });
                fs.unlinkSync(structuresFile, function (err) {
                    if (err) console.log(err);
                });
                setTimeout(function () {
                    start();
                }, 1500);
            }
            return;
        }
        for (var x = 0; x != sockets.length; x++) {
            sockets[x].emit("receive message", __username + "  :  " + message);
        }
    });
    socket.on("send logs", function(){
        sendLogs(socket);
    });
});

start();